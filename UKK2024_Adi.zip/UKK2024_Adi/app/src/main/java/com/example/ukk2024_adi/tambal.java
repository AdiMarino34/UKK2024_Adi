package com.example.ukk2024_adi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class tambal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tambal);
    }
}